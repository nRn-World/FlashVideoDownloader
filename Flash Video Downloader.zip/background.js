// Flash Video Downloader - Background Service Worker (v3.5.4)
// HLS downloads are delegated to offscreen.js which has full DOM/Blob/ObjectURL access.

importScripts('platform.js');
importScripts('blocked-hosts.js');
importScripts('license.js');
importScripts('terms-gate.js');

// Firefox for Android has no downloads API (Mozilla bug 1538348). platform.js owns
// that capability check; the fallback below repeats it only so this file also runs
// when it is loaded on its own, and so a test can drive the flag through a chrome stub.
const FVD_DL_API = typeof FVD_HAS_DOWNLOADS_API === 'undefined'
  ? (typeof chrome !== 'undefined' && !!chrome.downloads && typeof chrome.downloads.download === 'function')
  : FVD_HAS_DOWNLOADS_API;

// Shown only if a save is attempted with no download manager to hand it to.
const NO_DOWNLOAD_MANAGER = 'This browser does not let an extension save the file itself, so the file has to be saved from the download tab.';

const tabMedia = new Map();
const activeDownloads = new Map();
const cleanupScheduled = new Set();
const chromeDownloadMap = new Map(); // chrome.downloads id -> extension download id

function urlHasExt(urlLower, ext) {
  // Allow trailing slash after extension (common on KVS tube sites: .../720p.mp4/)
  return new RegExp(
    `\\.${ext.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?:\\/*(?:\\?|#|$)|\\/+)`,
    'i'
  ).test(urlLower);
}

// Media file extensions - utökad för alla tillåtna videokällor (sparas alltid som video)
const MEDIA_EXTENSIONS = [
  'mp4', 'm4v', 'm4s', 'fmp4', 'cmfv', 'cmfa',
  'webm', 'flv', 'f4v',
  'm3u8', 'm3u',
  'mpd',
  'ts', 'm2ts', 'mts',
  'mov', 'avi', 'mkv', 'ogv', '3gp', '3g2', 'wmv', 'av1', 'hevc', 'vob',
  'mp3', 'm4a', 'aac', 'wav', 'ogg', 'opus', 'flac', 'wma'
];

// Riktiga videobehållare. En URL som pekar på en av dessa är en äkta videofil och
// ska aldrig filtreras bort bara för att sökvägen råkar innehålla /preview/ eller /poster/.
const VIDEO_CONTAINER_EXTENSIONS = [
  'mp4', 'm4v', 'webm', 'mov', 'mkv', 'avi', 'flv', 'f4v',
  'ogv', 'ogm', '3gp', '3g2', 'wmv', 'asf', 'vob', 'm2v', 'divx',
  'mts', 'm2ts', 'mpg', 'mpeg', 'ts', 'm4s', 'fmp4', 'av1', 'hevc', 'h264', 'h265'
];

// Media MIME types - även generiska där filnamn indikerar video
const MEDIA_MIME_TYPES = [
  'video/', 'audio/',
  'application/x-mpegurl', 'application/vnd.apple.mpegurl',
  'application/dash+xml', 'application/vnd.ms-sstr+xml',
  'application/octet-stream', 'binary/octet-stream'
];

function formatBytes(bytes) {
  if (!bytes || isNaN(bytes) || bytes <= 0) return '';
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${sizes[i]}`;
}

function getFormat(url, contentType) {
  const urlLower = (url || '').toLowerCase();
  // Prioritera streaming-manifest (exakta filändelser – undvik att .fmp4 matchar .mp4)
  if (urlHasExt(urlLower, 'm3u8') || urlHasExt(urlLower, 'm3u') || (contentType && contentType.includes('mpegurl'))) return 'M3U8';
  if (urlHasExt(urlLower, 'mpd') || (contentType && contentType.includes('dash+xml'))) return 'MPD';
  for (const ext of MEDIA_EXTENSIONS) {
    if (urlHasExt(urlLower, ext)) return ext.toUpperCase();
  }
  if (contentType) {
    if (contentType.includes('mp4')) return 'MP4';
    if (contentType.includes('webm')) return 'WEBM';
    if (contentType.includes('mpegurl') || contentType.includes('m3u8')) return 'M3U8';
    if (contentType.includes('dash+xml')) return 'MPD';
    if (contentType.includes('flv')) return 'FLV';
    if (contentType.includes('quicktime') || contentType.includes('mov')) return 'MOV';
    if (contentType.includes('x-matroska') || contentType.includes('mkv')) return 'MKV';
    if (contentType.includes('mp3') || contentType.includes('mpeg')) return 'MP3';
    if (contentType.includes('ogg')) return 'OGG';
    if (contentType.includes('video/')) return 'MP4';
    if (contentType.includes('audio/')) return 'MP3';
  }
  return 'MP4';
}

function getCleanFilename(url, headerFilename, contentType) {
  let baseName = '';
  if (headerFilename) {
    baseName = headerFilename;
  } else {
    try {
      const workUrl = url.startsWith('blob:') ? url.slice(5) : url;
      const urlObj = new URL(workUrl);
      // Strip trailing slashes so .../720p.mp4/ still yields 720p.mp4
      const path = urlObj.pathname.replace(/\/+$/, '');
      let rawFilename = path.substring(path.lastIndexOf('/') + 1);
      if (rawFilename) baseName = decodeURIComponent(rawFilename.split('?')[0]);
    } catch (e) {}
  }

  if (!baseName || baseName.length < 2 || baseName === 'videoplayback' || baseName.startsWith('segment') || baseName.startsWith('master') || baseName.startsWith('index') || baseName.startsWith('playlist') || baseName.startsWith('chunk') || baseName.startsWith('frag') || baseName === 'get_file') {
    baseName = `video_${Date.now().toString().slice(-4)}`;
  }

  baseName = baseName.replace(/[/\\?%*:|"<>]/g, '_').replace(/\s+/g, ' ').trim();
  baseName = baseName.replace(/^[._]+|[._]+$/g, '').trim();
  if (baseName.length > 180) baseName = baseName.substring(0, 180).trim();
  baseName = baseName.replace(/\.(php|aspx|asp|jsp|html|htm|bin|do|cgi|axd|mpd)$/i, '');

  const hasKnownMediaExt = MEDIA_EXTENSIONS.some(ext => baseName.toLowerCase().endsWith('.' + ext));
  // Alla tillåtna källor sparas som video (.mp4) för maximal kompatibilitet, utom ren audio
  if (!hasKnownMediaExt) {
    const urlLower = (url || '').toLowerCase();
    const mimeLower = (contentType || '').toLowerCase();
    // behåll audio som mp3, annars alltid mp4
    const isAudioOnly = mimeLower.includes('audio/') && !mimeLower.includes('video') && !urlLower.includes('.mp4') && !urlLower.includes('.m3u8') && !urlLower.includes('.mpd') && !urlLower.includes('video');
    if (isAudioOnly) {
      baseName = `${baseName}.mp3`;
    } else {
      baseName = `${baseName}.mp4`;
    }
  } else {
    // Normalisera streaming-manifest till .mp4 så användaren får en spelbar video
    if (baseName.toLowerCase().endsWith('.m3u8') || baseName.toLowerCase().endsWith('.m3u') || baseName.toLowerCase().endsWith('.mpd')) {
      baseName = baseName.replace(/\.(m3u8|m3u|mpd)$/i, '.mp4');
    } else if (baseName.toLowerCase().endsWith('.ts') || baseName.toLowerCase().endsWith('.m4s') || baseName.toLowerCase().endsWith('.fmp4')) {
      baseName = baseName.replace(/\.(ts|m4s|fmp4)$/i, '.mp4');
    }
  }

  return baseName;
}

function isTubeCmsVideoUrl(url) {
  const u = (url || '').toLowerCase();
  // Kernel Video Sharing / similar adult CMS delivery paths
  if (/\/get_file\//i.test(u)) return true;
  if (/\/video[_-]?file\//i.test(u)) return true;
  if (/\/contents\/videos?\//i.test(u) && /\.(mp4|webm|m3u8|mov)/i.test(u)) return true;
  // pvvstream / JWPlayer progressive CDN (ukdevilz and similar)
  if (/pvvstream\.pro\/videos\//i.test(u) && /\.mp4/i.test(u)) return true;
  if (/\/vid_\d+p\.mp4/i.test(u)) return true;
  if (/\/vid\d*\//i.test(u) && /\.mp4/i.test(u)) return true;
  return false;
}

function isStreamingSegmentUrl(url) {
  const u = (url || '').toLowerCase();
  if (/\.(ts|m4s|fmp4|cmfv|cmfa|vtt|srt)(?:\/*(?:\?|#|$)|\/+)/i.test(u)) return true;
  if (/\/(segment|segments|chunk|chunks|frag|fragment)(\/|[_-]|\d)/i.test(u)) return true;
  return false;
}

function looksLikeStreamManifest(url, contentType) {
  const u = (url || '').toLowerCase();
  const ct = (contentType || '').toLowerCase();
  if (ct.includes('mpegurl') || ct.includes('dash+xml') || ct.includes('apple.mpegurl')) return true;
  if (urlHasExt(u, 'm3u8') || urlHasExt(u, 'm3u') || urlHasExt(u, 'mpd')) return true;
  // Extension-less HLS/DASH masters common on tube CDNs
  if (/\/(playlist|master|index|manifest)(?:[_.-][^/?#]*)?(?:\?|#|$)/i.test(u) && !isStreamingSegmentUrl(u)) return true;
  if (/\/hls\/[^?#]+/i.test(u) && !isStreamingSegmentUrl(u) && !/\.(ts|m4s)(?:\?|#|$)/i.test(u)) return true;
  return false;
}

function isPreviewMediaUrl(url) {
  const u = (url || '').toLowerCase();
  // Related trailers / poster images are never download targets
  if (/\/tr_\d+p\.mp4/i.test(u)) return true;
  if (/\/preview_\d+\.(jpg|jpeg|png|webp|gif)/i.test(u)) return true;
  // Fake site-local videofile stubs (404) – ignore
  if (/\/videofile\/[^/?#]+\.mp4(?:\?|#|$)/i.test(u) && !/pvvstream\.pro/i.test(u)) return true;
  // Real video files from tube CMS / quality variants are not previews
  if (isTubeCmsVideoUrl(u)) return false;
  if (/\/vid_\d+p\.mp4/i.test(u)) return false;
  if (/\b(240p|360p|480p|720p|1080p|1440p|2160p|4k)\b/i.test(u)) return false;
  if (urlHasExt(u, 'm3u8') || urlHasExt(u, 'mpd')) return false;
  // Match preview / trailer tokens as path or query parts
  if (/(?:^|[\/_\-.?&=])(thumbnails?|preview|trailer|poster|sprite|placeholder|avatar|favicon|banner)(?:[\/_\-.?&=]|$)/i.test(u)) return true;
  return false;
}

function addMediaItem(tabId, item) {
  if (!tabId || tabId < 0) return;
  if (item.url && typeof fvdIsBlockedUrl === 'function' && fvdIsBlockedUrl(item.url)) return;
  if (!tabMedia.has(tabId)) tabMedia.set(tabId, new Map());
  const mediaMap = tabMedia.get(tabId);
  if (mediaMap.has(item.url)) {
    const existing = mediaMap.get(item.url);
    const merged = { ...existing, ...item };
    if (!item.duration && existing.duration) merged.duration = existing.duration;
    if (!item.rawSize && existing.rawSize) merged.rawSize = existing.rawSize;
    if (!item.size && existing.size) merged.size = existing.size;
    if (existing.discoveredAt && !item.discoveredAt) merged.discoveredAt = existing.discoveredAt;
    mediaMap.set(item.url, merged);
  } else {
    mediaMap.set(item.url, item);
  }
  updateBadge(tabId);
}

const tabBadgeCounts = new Map(); // tabId -> verified count

function getComputedMediaCount(tabId) {
  const mediaMap = tabMedia.get(tabId);
  if (!mediaMap || mediaMap.size === 0) return 0;
  const items = Array.from(mediaMap.values()).filter(item => {
    if (!item || !item.url) return false;
    if (isStreamingSegmentUrl(item.url)) return false;
    if (isPreviewMediaUrl(item.url)) return false;
    return true;
  });
  if (items.length === 0) return 0;

  // Real player playlist sources take priority
  const playlistItems = items.filter(i => i.fromPlaylist);
  if (playlistItems.length > 0) {
    const uniqueUrls = new Set(playlistItems.map(i => i.url));
    return uniqueUrls.size;
  }

  const uniqueUrls = new Set(items.map(i => i.url));
  return uniqueUrls.size;
}

async function persistActiveDownloads() {
  try {
    await chrome.storage.session.set({
      activeDownloads: Array.from(activeDownloads.values())
    });
  } catch (e) { /* session storage unavailable on very old Chrome */ }
}

async function restoreActiveDownloads() {
  try {
    const data = await chrome.storage.session.get(['activeDownloads']);
    if (!data.activeDownloads || !Array.isArray(data.activeDownloads)) return;
    for (const dl of data.activeDownloads) {
      if (!dl || !dl.id) continue;
      if (dl.status === 'downloading' || dl.status === 'paused' || dl.status === 'merging') {
        dl.status = 'error';
        dl.error = 'Download interrupted (extension restarted). Please try again.';
      }
      activeDownloads.set(dl.id, dl);
    }
    updateBadge();
  } catch (e) {}
}

function updateBadge(tabId) {
  let activeDlCount = 0;
  let pausedCount = 0;
  for (const dl of activeDownloads.values()) {
    if (dl.status === 'downloading' || dl.status === 'merging') activeDlCount++;
    if (dl.status === 'paused') pausedCount++;
  }
  if (activeDlCount > 0) {
    chrome.action.setBadgeText({ text: '⚡' });
    chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
    return;
  }
  if (pausedCount > 0) {
    chrome.action.setBadgeText({ text: '⏸' });
    chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
    return;
  }
  if (tabId) {
    let count = 0;
    if (tabBadgeCounts.has(tabId)) {
      count = tabBadgeCounts.get(tabId);
    } else {
      count = getComputedMediaCount(tabId);
    }
    if (count > 0) {
      chrome.action.setBadgeText({ tabId, text: count.toString() });
      chrome.action.setBadgeBackgroundColor({ tabId, color: '#2563eb' });
    } else {
      chrome.action.setBadgeText({ tabId, text: '' });
    }
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

// === Network Sniffing ===
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.tabId < 0) return;
    const url = details.url;
    if (!url || fvdIsBlockedUrl(url)) return;

    let contentType = '';
    let contentLength = 0;
    let contentDispositionFilename = '';

    if (details.responseHeaders) {
      for (const header of details.responseHeaders) {
        const name = header.name.toLowerCase();
        if (name === 'content-type') contentType = (header.value || '').toLowerCase();
        else if (name === 'content-length') contentLength = parseInt(header.value, 10) || 0;
        else if (name === 'content-range') {
          const match = /\/(\d+)/.exec(header.value || '');
          if (match && match[1]) {
            const totalBytes = parseInt(match[1], 10) || 0;
            if (totalBytes > 0) contentLength = totalBytes;
          }
        }
        else if (name === 'content-disposition') {
          const match = /filename\*?=['"]?(?:UTF-\d['"]*)?([^;\r\n"']*)['"]?/i.exec(header.value || '');
          if (match && match[1]) contentDispositionFilename = decodeURIComponent(match[1]);
        }
      }
    }

    const isMediaMime = MEDIA_MIME_TYPES.some(type => {
      if (type === 'application/octet-stream' || type === 'binary/octet-stream') {
        // generisk binär räknas bara som media om filnamn/extension hintar video eller disposition finns
        return contentType === type && (contentDispositionFilename || MEDIA_EXTENSIONS.some(ext => url.toLowerCase().includes('.'+ext)) || isTubeCmsVideoUrl(url));
      }
      return contentType.startsWith(type);
    });
    const urlLower = url.toLowerCase();
    const hasMediaExt = MEDIA_EXTENSIONS.some(ext => urlHasExt(urlLower, ext));
    const hasDispositionVideo = contentDispositionFilename && MEDIA_EXTENSIONS.some(ext => contentDispositionFilename.toLowerCase().endsWith('.'+ext));
    const looksLikeTubeVideo = isTubeCmsVideoUrl(url);
    const looksLikeManifest = looksLikeStreamManifest(url, contentType);

    if (contentLength > 0 && contentLength < 15000 && !looksLikeManifest && !urlLower.includes('.m3u8') && !urlLower.includes('.mpd') && !urlLower.includes('.m3u') && !looksLikeTubeVideo) return;

    if (isStreamingSegmentUrl(url) || isPreviewMediaUrl(url)) return;

    if (isMediaMime || hasMediaExt || hasDispositionVideo || looksLikeTubeVideo || looksLikeManifest) {
      // Never show file size for streaming manifests - 6.5KB is the playlist, not the video (would be false info for a 21min video)
      const isManifest = looksLikeManifest || urlLower.includes('.m3u8') || urlLower.includes('.m3u') || urlLower.includes('.mpd') || urlLower.includes('.m4s') || urlLower.includes('.fmp4') || (contentType.includes('mpegurl') || contentType.includes('dash+xml'));
      const format = getFormat(url, contentType);
      const STREAM_FORMATS = new Set(['M3U8','M3U','MPD','M4S','FMP4','TS','M2TS']);
      const isStreamFormat = STREAM_FORMATS.has(format);
      const reliableSize = (!isManifest && !isStreamFormat && contentLength > 0) ? formatBytes(contentLength) : '';
      const reliableRaw = (!isManifest && !isStreamFormat && contentLength > 0) ? contentLength : 0;
      addMediaItem(details.tabId, {
        url, filename: getCleanFilename(url, contentDispositionFilename, contentType),
        format: looksLikeManifest && format === 'MP4' ? 'M3U8' : format, size: reliableSize,
        rawSize: reliableRaw, contentType, initiator: details.initiator || '',
        discoveredAt: Date.now()
      });
    }
  },
  { urls: ['<all_urls>'] },
  ['responseHeaders']
);

// ── Terms gate for page injection ─────────────────────────────────────────────
// The content script must not reach a page before the user has accepted the
// Agreement, or the extension would already be scanning and capturing media for
// someone who has never seen the terms. The download gate in gateDownloadStart()
// stops the saving, but not this scan, so both are needed.
//
// The state is cached so the common path stays synchronous: a storage read on
// every navigation would delay the MAIN-world hook past the first media request,
// which is exactly what the hook exists to capture. chrome.storage.local survives
// an update, so an existing user keeps their record; a reinstall clears storage
// and the gate is up again.
let fvdTermsAcceptedCache = null;

if (chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes[FVD_TERMS_ACK_KEY]) return;
    fvdTermsAcceptedCache = termsRecordSatisfies(changes[FVD_TERMS_ACK_KEY].newValue, FVD_TERMS_VERSION);
  });
}

async function termsAcceptedForInjection() {
  if (fvdTermsAcceptedCache !== null) return fvdTermsAcceptedCache;
  try {
    fvdTermsAcceptedCache = !(await termsAcceptanceRequired());
  } catch (e) {
    // Fail open, the same rule terms-gate.js applies: never lock a user out of
    // their browser because storage misbehaved.
    console.warn('[FVD] Could not read the terms acknowledgement:', e);
    fvdTermsAcceptedCache = true;
  }
  return fvdTermsAcceptedCache;
}

async function injectContentScriptAfterAcceptance(tabId) {
  try {
    if (await termsAcceptedForInjection()) await ensureContentScript(tabId);
  } catch (e) {
    console.warn('[FVD] content script injection skipped:', e && e.message ? e.message : e);
  }
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url) {
    tabMedia.set(tabId, new Map());
    tabBadgeCounts.delete(tabId);
    updateBadge(tabId);
  }
  if ((changeInfo.status === 'complete' || changeInfo.status === 'loading') && tab && tab.url && /^https?:/i.test(tab.url)) {
    if (typeof fvdIsBlockedUrl === 'function' && fvdIsBlockedUrl(tab.url)) return;
    // Install MAIN-world hook early so HLS and player sources are captured while the user watches
    injectContentScriptAfterAcceptance(tabId);
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  tabMedia.delete(tabId);
  tabBadgeCounts.delete(tabId);
});

// === Offscreen Document Management ===
// Chrome: chrome.offscreen API. Firefox: hidden iframe in background-page.html (no offscreen API).
// Firefox for Android: the engine cannot save anything (no downloads API), so it has
// to run somewhere the file itself is reachable. A real tab is that place - a hidden
// iframe cannot be tapped, and a programmatic click there is not guaranteed to start a
// download. The tab is reused across downloads instead of piling up copies.
let engineTabId = null;

async function findEngineTabId() {
  let url;
  try {
    url = chrome.runtime.getURL('offscreen.html');
  } catch (e) {
    return engineTabId;
  }
  try {
    const tabs = await chrome.tabs.query({ url });
    if (tabs && tabs.length && tabs[0].id != null) return tabs[0].id;
  } catch (e) {
    // tabs.query with a url pattern is the reliable lookup; the tracked id is the fallback.
  }
  return engineTabId;
}

async function ensureEngineTab() {
  let tabId = await findEngineTabId();

  if (tabId == null) {
    try {
      const tab = await chrome.tabs.create({ url: chrome.runtime.getURL('offscreen.html'), active: false });
      tabId = tab && tab.id != null ? tab.id : null;
    } catch (e) {
      console.warn('[FVD] could not open the download engine tab:', e && e.message ? e.message : e);
      return null;
    }
  }
  engineTabId = tabId;
  if (tabId == null) return null;

  // A fresh tab is not listening yet: offscreen.js registers its handler at the end of
  // its own load. Sending the download before that rejects, and the download would be
  // marked failed even though nothing was wrong.
  const deadline = Date.now() + 10000;
  while (Date.now() < deadline) {
    let tab = null;
    try {
      tab = await chrome.tabs.get(tabId);
    } catch (e) {
      engineTabId = null;
      return null;
    }
    if (tab && tab.status === 'complete') break;
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  return tabId;
}

async function ensureOffscreenDocument() {
  if (!FVD_DL_API) {
    await ensureEngineTab();
    return;
  }
  try {
    // Firefox / event-page path: offscreen.html is loaded in #fvd-offscreen iframe
    if (typeof document !== 'undefined') {
      const frame = document.getElementById('fvd-offscreen');
      if (frame) {
        if (frame.dataset.ready === '1') return;
        await new Promise((resolve) => {
          const done = () => {
            frame.dataset.ready = '1';
            resolve();
          };
          try {
            if (frame.contentDocument && frame.contentDocument.readyState === 'complete') {
              done();
              return;
            }
          } catch (e) {}
          frame.addEventListener('load', done, { once: true });
          // Safety timeout so downloads are not blocked forever
          setTimeout(done, 1500);
        });
        return;
      }
    }

    if (!chrome.offscreen || typeof chrome.offscreen.hasDocument !== 'function') {
      console.warn('[FVD] chrome.offscreen not available');
      return;
    }
    if (await chrome.offscreen.hasDocument()) return;
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['BLOBS'],
      justification: 'Download HLS segments, merge into full video, and save to disk via DOM Blob/ObjectURL'
    });
    await new Promise(r => setTimeout(r, 80));
  } catch (e) {
    console.warn('[FVD] ensureOffscreenDocument failed:', e && e.message ? e.message : e);
  }
}

async function setDownloadControlFlag(downloadId, control) {
  const key = 'dlCtrl_' + downloadId;
  await chrome.storage.session.set({ [key]: control });
}

async function clearDownloadControlFlag(downloadId) {
  try {
    await chrome.storage.session.remove('dlCtrl_' + downloadId);
  } catch (e) {}
}

async function forwardToOffscreen(type, downloadId) {
  await ensureOffscreenDocument();
  try {
    return await chrome.runtime.sendMessage({ type, downloadId });
  } catch (e) {
    return null;
  }
}

// === Download History ===
function sanitizeHistoryUrl(url) {
  try {
    const u = new URL(url);
    u.search = '';
    u.hash = '';
    return u.href;
  } catch (e) {
    return (url || '').split('?')[0].split('#')[0];
  }
}

async function shouldPromptForSave() {
  try {
    if (!chrome.storage || !chrome.storage.local) return false;
    const data = await chrome.storage.local.get(['askSaveEachTime', 'useDefaultDownloadFolder', 'useCustomDirectory']);
    if (data.useDefaultDownloadFolder === true && data.useCustomDirectory === true) {
      return false;
    }
    return data.askSaveEachTime === true;
  } catch (e) {
    return false;
  }
}

function emitDownloadProgress(dl) {
  if (!dl) return;
  chrome.runtime.sendMessage({ type: 'OFFSCREEN_PROGRESS', state: { ...dl } }).catch(() => {});
}

function scheduleDownloadCleanup(extId) {
  if (cleanupScheduled.has(extId)) return;
  cleanupScheduled.add(extId);
  setTimeout(() => {
    cleanupScheduled.delete(extId);
    const cur = activeDownloads.get(extId);
    if (cur && (cur.status === 'completed' || cur.status === 'error')) {
      activeDownloads.delete(extId);
      persistActiveDownloads();
      updateBadge();
    }
  }, 45000);
}

// Review prompts at download milestones 1, 5 and 10 (popup reads pendingReviewMilestone).
const REVIEW_MILESTONES = [1, 5, 10];
const reviewCountedDownloadIds = new Set();

async function maybeFlagReviewPrompt(downloadId) {
  try {
    if (downloadId) {
      if (reviewCountedDownloadIds.has(downloadId)) return;
      reviewCountedDownloadIds.add(downloadId);
      // Avoid unbounded growth in the service worker
      if (reviewCountedDownloadIds.size > 200) {
        reviewCountedDownloadIds.clear();
        reviewCountedDownloadIds.add(downloadId);
      }
    }

    const data = await chrome.storage.local.get([
      'successfulDownloadCount',
      'reviewPromptsShown',
      'pendingReviewMilestone'
    ]);
    const count = (Number(data.successfulDownloadCount) || 0) + 1;
    const shown = Array.isArray(data.reviewPromptsShown) ? data.reviewPromptsShown : [];
    const updates = { successfulDownloadCount: count };

    if (!data.pendingReviewMilestone) {
      for (const m of REVIEW_MILESTONES) {
        if (count >= m && !shown.includes(m)) {
          updates.pendingReviewMilestone = m;
          break;
        }
      }
    }

    await chrome.storage.local.set(updates);
  } catch (e) {
    console.warn('[FVD] review prompt flag:', e && e.message ? e.message : e);
  }
}

function completeTrackedDownload(extId) {
  const dl = activeDownloads.get(extId);
  if (!dl) return;
  dl.status = 'completed';
  dl.percent = 100;
  activeDownloads.set(extId, dl);
  persistActiveDownloads();
  emitDownloadProgress(dl);
  maybeFlagReviewPrompt(extId);

  Promise.resolve(
    saveDownloadToHistory({
      filename: dl.filename,
      url: dl.url,
      size: dl.size || 'Direct',
      duration: dl.duration || ''
    })
  ).catch((e) => console.warn('[FVD] history save:', e && e.message ? e.message : e));
  updateBadge();
  scheduleDownloadCleanup(extId);

  // If Free user, open the download success partner page in a new tab
  if (typeof isProUser === 'function') {
    isProUser().then((status) => {
      if (!status || !status.isPro) {
        chrome.tabs.create({ url: chrome.runtime.getURL('download-success.html') });
      }
    }).catch(() => {});
  }
}

function failTrackedDownload(extId, message) {
  const dl = activeDownloads.get(extId);
  if (!dl) return;
  dl.status = 'error';
  dl.error = message || 'Download failed';
  activeDownloads.set(extId, dl);
  persistActiveDownloads();
  emitDownloadProgress(dl);
  updateBadge();
  scheduleDownloadCleanup(extId);
}

// Declared here and attached below only where the API exists: at top level on a
// browser without it the registration would throw while the background loads, and
// that would take every other feature down with it.
function handleChromeDownloadChanged(delta) {
  const extId = chromeDownloadMap.get(delta.id);
  if (!extId) return;
  const dl = activeDownloads.get(extId);
  if (!dl) return;

  // Chrome often sends bytesReceived and totalBytes in separate onChanged events.
  // Remember total size so later byte updates can compute percent.
  if (delta.totalBytes && typeof delta.totalBytes.current === 'number' && delta.totalBytes.current > 0) {
    dl.downloadTotalBytes = delta.totalBytes.current;
  }
  if (delta.fileSize && typeof delta.fileSize.current === 'number' && delta.fileSize.current > 0) {
    dl.downloadTotalBytes = Math.max(dl.downloadTotalBytes || 0, delta.fileSize.current);
  }

  if (delta.bytesReceived && typeof delta.bytesReceived.current === 'number') {
    const received = delta.bytesReceived.current || 0;
    dl.totalBytes = received;
    const total = dl.downloadTotalBytes || 0;
    if (total > 0) {
      dl.percent = Math.min(99, Math.round((received / total) * 100));
    } else if (received > 0) {
      // Unknown Content-Length: show activity instead of staying stuck at 15%
      // Rough curve from ~15% toward 90% as bytes grow
      const approx = 15 + Math.min(75, Math.floor(Math.log10(received + 10) * 15));
      dl.percent = Math.max(dl.percent || 15, Math.min(90, approx));
    }
    activeDownloads.set(extId, dl);
    persistActiveDownloads();
    emitDownloadProgress(dl);
    if (dl.status === 'downloading') {
      chrome.action.setBadgeText({ text: `${dl.percent}%` });
      chrome.action.setBadgeBackgroundColor({ color: '#3b82f6' });
    }
  }

  if (delta.state && delta.state.current === 'complete') {
    stopChromeDownloadPoll(delta.id);
    chromeDownloadMap.delete(delta.id);
    completeTrackedDownload(extId);
  } else if (delta.error || (delta.state && delta.state.current === 'interrupted')) {
    stopChromeDownloadPoll(delta.id);
    chromeDownloadMap.delete(delta.id);
    const errText = (delta.error && delta.error.current) || (delta.state && delta.state.current) || 'Download interrupted';
    if (!dl.triedOffscreenFallback && (errText.includes('FORBIDDEN') || errText.includes('FAILED') || errText.includes('UNAUTHORIZED') || errText.includes('BAD_CONTENT') || errText.includes('interrupted'))) {
      dl.triedOffscreenFallback = true;
      activeDownloads.set(extId, dl);
      console.warn('[FVD] Native download error (' + errText + '), falling back to offscreen fetch with referer for ' + extId);
      ensureOffscreenDocument().then(() => {
        chrome.runtime.sendMessage({
          type: 'START_OFFSCREEN_GENERIC',
          downloadId: extId,
          url: dl.url,
          filename: dl.filename,
          pageReferer: dl.pageReferer || null
        }).catch(() => {
          failTrackedDownload(extId, errText);
        });
      }).catch(() => {
        failTrackedDownload(extId, errText);
      });
    } else {
      failTrackedDownload(extId, errText);
    }
  }
}

if (FVD_DL_API) {
  chrome.downloads.onChanged.addListener(handleChromeDownloadChanged);
}

async function ensureContentScript(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      world: 'MAIN',
      files: ['page-hook.js']
    });
  } catch (e) {
    console.warn('[FVD] page-hook inject:', e && e.message ? e.message : e);
  }
  try {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      files: ['blocked-hosts.js', 'content.js']
    });
  } catch (e) {
    console.warn('[FVD] ensureContentScript:', e && e.message ? e.message : e);
  }
}

async function collectMainWorldMedia(tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: () => {
        try {
          if (typeof globalThis.__FVD_COLLECT_PAGE_MEDIA__ === 'function') {
            return globalThis.__FVD_COLLECT_PAGE_MEDIA__();
          }
        } catch (e) {}
        return { hls: [], standard: [], model: [], perf: [] };
      }
    });
    return (results && results[0] && results[0].result) || null;
  } catch (e) {
    console.warn('[FVD] collectMainWorldMedia:', e && e.message ? e.message : e);
    return null;
  }
}

async function saveFileViaDownloads(blobUrl, filename) {
  if (!FVD_DL_API) throw new Error(NO_DOWNLOAD_MANAGER);
  const safeName = (filename || 'video.mp4').replace(/[/\\?%*:|"<>]/g, '_').replace(/^\/+/, '');
  return chrome.downloads.download({
    url: blobUrl,
    filename: safeName,
    saveAs: await shouldPromptForSave()
  });
}

async function saveUrlViaDownloads(fileUrl, filename, pageReferer) {
  // Throwing here is deliberate: the caller already falls back to the engine for any
  // download-manager failure, and the engine is exactly where an Android save happens.
  if (!FVD_DL_API) throw new Error(NO_DOWNLOAD_MANAGER);
  const safeName = (filename || 'video.mp4').replace(/[/\\?%*:|"<>]/g, '_').replace(/^\/+/, '');
  const options = {
    url: fileUrl,
    filename: safeName,
    saveAs: await shouldPromptForSave()
  };
  if (pageReferer && /^https?:\/\//i.test(pageReferer)) {
    options.headers = [{ name: 'Referer', value: pageReferer }];
  }
  return chrome.downloads.download(options);
}

// Poll chrome.downloads for progress — onChanged alone often misses byte updates.
const chromeDownloadPollers = new Map(); // chromeDlId -> intervalId

function stopChromeDownloadPoll(chromeDlId) {
  const t = chromeDownloadPollers.get(chromeDlId);
  if (t) {
    clearInterval(t);
    chromeDownloadPollers.delete(chromeDlId);
  }
}

function startChromeDownloadPoll(chromeDlId, extId) {
  if (!FVD_DL_API) return;
  stopChromeDownloadPoll(chromeDlId);
  const tick = async () => {
    try {
      if (!chromeDownloadMap.has(chromeDlId)) {
        stopChromeDownloadPoll(chromeDlId);
        return;
      }
      const items = await chrome.downloads.search({ id: chromeDlId });
      const item = items && items[0];
      if (!item) return;
      const dl = activeDownloads.get(extId);
      if (!dl || dl.status === 'completed' || dl.status === 'error' || dl.status === 'cancelled') {
        stopChromeDownloadPoll(chromeDlId);
        return;
      }

      if (item.totalBytes > 0) dl.downloadTotalBytes = item.totalBytes;
      else if (item.fileSize > 0) dl.downloadTotalBytes = item.fileSize;

      const received = item.bytesReceived || 0;
      if (received > 0) dl.totalBytes = received;

      const total = dl.downloadTotalBytes || 0;
      let pct = dl.percent || 15;
      if (total > 0 && received >= 0) {
        pct = Math.min(99, Math.round((received / total) * 100));
      } else if (received > 0) {
        const approx = 15 + Math.min(75, Math.floor(Math.log10(received + 10) * 15));
        pct = Math.max(pct, Math.min(90, approx));
      }

      if (pct !== dl.percent || received !== (dl._lastPolledBytes || 0)) {
        dl.percent = pct;
        dl._lastPolledBytes = received;
        activeDownloads.set(extId, dl);
        emitDownloadProgress(dl);
        if (dl.status === 'downloading') {
          chrome.action.setBadgeText({ text: `${dl.percent}%` });
          chrome.action.setBadgeBackgroundColor({ color: '#3b82f6' });
        }
      }

      if (item.state === 'complete' || item.state === 'interrupted') {
        stopChromeDownloadPoll(chromeDlId);
      }
    } catch (e) {
      // ignore transient poll errors
    }
  };
  chromeDownloadPollers.set(chromeDlId, setInterval(tick, 400));
  tick();
}

async function saveDownloadToHistory(item) {
  try {
    if (!chrome.storage || !chrome.storage.local) return;
    const data = await chrome.storage.local.get(['downloadHistory', 'autoDelete24h']);
    let history = data.downloadHistory || [];
    const autoDelete = data.autoDelete24h !== false;
    const now = Date.now();
    if (autoDelete) history = history.filter(h => h.timestamp > now - 86400000);
    history.unshift({
      id: 'dl_' + now,
      filename: item.filename,
      url: sanitizeHistoryUrl(item.url),
      size: item.size || 'N/A',
      duration: item.duration || 'N/A',
      timestamp: now
    });
    if (history.length > 50) history = history.slice(0, 50);
    await chrome.storage.local.set({ downloadHistory: history });
  } catch (e) { console.warn('[FVD] Failed to save history:', e && e.message ? e.message : e); }
}

async function purgeExpiredHistory() {
  try {
    const data = await chrome.storage.local.get(['downloadHistory', 'autoDelete24h']);
    if (data.autoDelete24h !== false && data.downloadHistory) {
      const cleaned = data.downloadHistory.filter(h => h.timestamp > Date.now() - 86400000);
      await chrome.storage.local.set({ downloadHistory: cleaned });
    }
  } catch (e) {
    console.warn('[FVD] purgeExpiredHistory:', e && e.message ? e.message : e);
  }
}
try {
  purgeExpiredHistory();
  restoreActiveDownloads();
  chrome.action.setBadgeText({ text: '' }).catch(() => {});
} catch(e) {}

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    chrome.storage.local.set({
      useDefaultDownloadFolder: false,
      useCustomDirectory: false,
      askSaveEachTime: false,
      autoDelete24h: true,
      showWelcomeTip: true
    });
    try {
      chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') });
    } catch (e) {
      console.warn('[FVD] Could not open welcome page', e);
    }
  }
});

self.addEventListener('error', (e) => console.error('[FVD background error]', e && e.message ? e.message : e));
self.addEventListener('unhandledrejection', (e) => console.error('[FVD unhandled]', e && e.reason ? e.reason : e));

// === HLS / Generic Download Trigger (delegates to offscreen.js) ===
async function canStartNewDownload() {
  try {
    const limits = await getFeatureLimits();
    const maxConcurrent = limits.concurrentDownloads;
    
    // Count currently active downloads (downloading, merging, paused)
    let activeCount = 0;
    for (const dl of activeDownloads.values()) {
      if (dl.status === 'downloading' || dl.status === 'merging' || dl.status === 'paused') {
        activeCount++;
      }
    }
    
    return activeCount < maxConcurrent;
  } catch (e) {
    // Default to 1 if check fails
    return activeDownloads.size === 0;
  }
}

function notifyRateLimit(minutesRemaining) {
  chrome.runtime.sendMessage({
    type: 'RATE_LIMIT_REACHED',
    minutesRemaining: minutesRemaining || FREE_RATE_WINDOW_MINUTES,
    requiresUpgrade: true
  }).catch(() => {});
}

function notifyConcurrentLimit() {
  chrome.runtime.sendMessage({
    type: 'DOWNLOAD_LIMIT_REACHED',
    message: 'Free users can only download 1 video at a time. Upgrade to Pro for 3 concurrent downloads.',
    requiresUpgrade: true
  }).catch(() => {});
}

function notifyTermsRequired() {
  chrome.runtime.sendMessage({
    type: 'TERMS_ACCEPTANCE_REQUIRED',
    termsVersion: typeof FVD_TERMS_VERSION === 'string' ? FVD_TERMS_VERSION : null
  }).catch(() => {});
}

// Enforce Free: 1 per window + 1 concurrent. Consumes the slot only when start is allowed.
// The window length lives in license.js (FREE_RATE_WINDOW_HOURS).
async function gateDownloadStart() {
  try {
    // Terms of Service first: every download type (HLS, DASH, chunked, generic,
    // blob) funnels through here, and this is the one place the popup cannot skip.
    // Checked before the concurrency/rate-limit checks so a refused start never
    // burns the user's free download slot.
    if (typeof termsAcceptanceRequired === 'function' && await termsAcceptanceRequired()) {
      notifyTermsRequired();
      return { ok: false, status: 'terms_required' };
    }

    if (!(await canStartNewDownload())) {
      notifyConcurrentLimit();
      return { ok: false, status: 'concurrent_limit' };
    }

    if (typeof consumeFreeDownloadSlot !== 'function') {
      notifyRateLimit(FREE_RATE_WINDOW_MINUTES);
      return { ok: false, status: 'rate_limited', minutesRemaining: FREE_RATE_WINDOW_MINUTES };
    }

    const rate = await consumeFreeDownloadSlot();
    if (!rate.allowed) {
      notifyRateLimit(rate.minutesRemaining);
      return {
        ok: false,
        status: 'rate_limited',
        minutesRemaining: rate.minutesRemaining || FREE_RATE_WINDOW_MINUTES
      };
    }

    return { ok: true, status: 'started' };
  } catch (e) {
    console.warn('[FVD] Download gate failed:', e);
    notifyRateLimit(FREE_RATE_WINDOW_MINUTES);
    return { ok: false, status: 'rate_limited', minutesRemaining: FREE_RATE_WINDOW_MINUTES };
  }
}

async function startHlsDownload(downloadId, playlistUrl, filename, pageReferer) {
  const gate = await gateDownloadStart();
  if (!gate.ok) return gate;

  try {
    activeDownloads.set(downloadId, {
      id: downloadId, url: playlistUrl, filename: filename,
      status: 'downloading', completed: 0, total: 0, percent: 0,
      totalDurationSec: 0, downloadedDurationSec: 0,
      totalDurationFormatted: '', downloadedDurationFormatted: '',
      error: null, totalBytes: 0
    });
    updateBadge();
    persistActiveDownloads();
    await ensureOffscreenDocument();
    try {
      await chrome.runtime.sendMessage({
        type: 'START_OFFSCREEN_HLS',
        downloadId: downloadId,
        url: playlistUrl,
        filename: filename,
        pageReferer: pageReferer || null
      });
    } catch (e) {
      // Fallback to direct download if offscreen not available
      console.warn('[FVD] HLS offscreen failed, fallback:', e && e.message);
      activeDownloads.set(downloadId, { ...activeDownloads.get(downloadId), status: 'error', error: 'Download engine not available. Update your browser and try again.' });
      updateBadge();
    }
  } catch (e) { console.error('[FVD] startHlsDownload', e); }
  return { ok: true, status: 'started' };
}

async function startDashDownload(downloadId, mpdUrl, filename, pageReferer) {
  const gate = await gateDownloadStart();
  if (!gate.ok) return gate;

  try {
    activeDownloads.set(downloadId, {
      id: downloadId, url: mpdUrl, filename: filename,
      status: 'downloading', completed: 0, total: 0, percent: 0,
      totalDurationSec: 0, downloadedDurationSec: 0,
      totalDurationFormatted: '', downloadedDurationFormatted: '',
      error: null, totalBytes: 0
    });
    updateBadge();
    persistActiveDownloads();
    await ensureOffscreenDocument();
    try {
      await chrome.runtime.sendMessage({
        type: 'START_OFFSCREEN_DASH',
        downloadId,
        url: mpdUrl,
        filename,
        pageReferer: pageReferer || null
      });
    } catch (e) {
      console.warn('[FVD] DASH offscreen failed:', e && e.message);
      activeDownloads.set(downloadId, {
        ...activeDownloads.get(downloadId),
        status: 'error',
        error: 'Download engine not available. Update your browser and try again.'
      });
      updateBadge();
    }
  } catch (e) { console.error('[FVD] startDashDownload', e); }
  return { ok: true, status: 'started' };
}

async function startBlobDownload(downloadId, tabId, blobUrl, filename) {
  const gate = await gateDownloadStart();
  if (!gate.ok) return gate;

  const dlState = {
    id: downloadId, url: blobUrl, filename: filename,
    status: 'downloading', completed: 0, total: 1, percent: 0,
    totalDurationSec: 0, downloadedDurationSec: 0,
    totalDurationFormatted: '', downloadedDurationFormatted: '',
    error: null, totalBytes: 0
  };
  activeDownloads.set(downloadId, dlState);
  updateBadge();
  persistActiveDownloads();

  // Firefox for Android: a page cannot hand the file to a download manager either, and a
  // click the extension makes on the user's behalf may simply be ignored. So the bytes are
  // read through the content script and the engine tab offers them as a link to tap -
  // the same finish every other Android download gets.
  if (!FVD_DL_API) {
    try {
      await ensureContentScript(tabId);
      const fetched = await chrome.tabs.sendMessage(tabId, { type: 'FETCH_BLOB', url: blobUrl });
      if (!fetched || fetched.error || !fetched.buffer) {
        throw new Error((fetched && fetched.error) || 'Could not read the video from the page');
      }
      await ensureOffscreenDocument();
      await chrome.runtime.sendMessage({
        type: 'START_OFFSCREEN_BUFFER',
        downloadId: downloadId,
        filename: filename,
        buffer: fetched.buffer
      });
      return { ok: true, status: 'started' };
    } catch (e) {
      console.error('[FVD] startBlobDownload (Android)', e);
      failTrackedDownload(downloadId, e && e.message ? e.message : 'Blob download failed');
      return { ok: false, status: 'error' };
    }
  }

  try {
    await ensureContentScript(tabId);
    const blobResponse = await chrome.tabs.sendMessage(tabId, {
      type: 'DOWNLOAD_BLOB',
      url: blobUrl,
      filename: filename
    });

    if (blobResponse && blobResponse.ok) {
      dlState.status = 'completed';
      dlState.percent = 100;
      dlState.totalBytes = blobResponse.size || 0;
      activeDownloads.set(downloadId, dlState);
      persistActiveDownloads();
      emitDownloadProgress(dlState);
      maybeFlagReviewPrompt(downloadId);
      saveDownloadToHistory({
        filename,
        url: blobUrl,
        size: blobResponse.size ? formatBytes(blobResponse.size) : 'Blob',
        duration: ''
      });
      updateBadge();
      scheduleDownloadCleanup(downloadId);
      return { ok: true, status: 'started' };
    }

    const errMsg = blobResponse && blobResponse.error ? blobResponse.error : 'Blob download failed';
    throw new Error(errMsg);
  } catch (e) {
    console.error('[FVD] startBlobDownload', e);
    failTrackedDownload(downloadId, e && e.message ? e.message : 'Blob download failed');
    return { ok: false, status: 'error' };
  }
}

async function startGenericDownload(downloadId, fileUrl, filename, pageReferer) {
  if (fileUrl && fileUrl.startsWith('blob:')) {
    console.warn('[FVD] blob: URL must use START_BLOB_DOWNLOAD');
    return { ok: false, status: 'error' };
  }

  const gate = await gateDownloadStart();
  if (!gate.ok) return gate;

  const dlState = {
    id: downloadId, url: fileUrl, filename: filename,
    status: 'downloading', completed: 0, total: 1, percent: 5,
    totalDurationSec: 0, downloadedDurationSec: 0,
    totalDurationFormatted: '', downloadedDurationFormatted: '',
    error: null, totalBytes: 0,
    pageReferer: pageReferer || null
  };
  activeDownloads.set(downloadId, dlState);
  updateBadge();
  persistActiveDownloads();

  try {
    const chromeDlId = await saveUrlViaDownloads(fileUrl, filename, pageReferer);
    chromeDownloadMap.set(chromeDlId, downloadId);
    dlState.percent = 15;
    activeDownloads.set(downloadId, dlState);
    persistActiveDownloads();
    emitDownloadProgress(dlState);
    startChromeDownloadPoll(chromeDlId, downloadId);
  } catch (primaryErr) {
    console.warn('[FVD] chrome.downloads failed, trying offscreen fetch:', primaryErr && primaryErr.message);
    try {
      await ensureOffscreenDocument();
      await chrome.runtime.sendMessage({
        type: 'START_OFFSCREEN_GENERIC',
        downloadId: downloadId,
        url: fileUrl,
        filename: filename,
        pageReferer: pageReferer || null
      });
    } catch (fallbackErr) {
      failTrackedDownload(
        downloadId,
        (primaryErr && primaryErr.message) || (fallbackErr && fallbackErr.message) || 'Download failed'
      );
      return { ok: false, status: 'error' };
    }
  }
  return { ok: true, status: 'started' };
}

// Parallel chunk downloader — routes to offscreen runChunkedDownload
// threads=1: normal (single stream), threads=4: fast, threads=8: pro
async function startChunkedDownload(downloadId, fileUrl, filename, pageReferer, threads) {
  if (fileUrl && fileUrl.startsWith('blob:')) {
    return startGenericDownload(downloadId, fileUrl, filename, pageReferer);
  }

  const gate = await gateDownloadStart();
  if (!gate.ok) return gate;

  const dlState = {
    id: downloadId, url: fileUrl, filename: filename,
    status: 'downloading', completed: 0, total: 1, percent: 5,
    totalDurationSec: 0, downloadedDurationSec: 0,
    totalDurationFormatted: '', downloadedDurationFormatted: '',
    error: null, totalBytes: 0,
    pageReferer: pageReferer || null
  };
  activeDownloads.set(downloadId, dlState);
  updateBadge();
  persistActiveDownloads();

  try {
    await ensureOffscreenDocument();
    await chrome.runtime.sendMessage({
      type: 'START_OFFSCREEN_CHUNKED',
      downloadId: downloadId,
      url: fileUrl,
      filename: filename,
      pageReferer: pageReferer || null,
      threads: threads || 1
    });
  } catch (err) {
    console.warn('[FVD] Chunked offscreen failed, falling back to generic:', err && err.message);
    return startGenericDownload(downloadId, fileUrl, filename, pageReferer);
  }

  return { ok: true, status: 'started' };
}

function resolvePageReferer(message) {
  if (message.pageReferer) return message.pageReferer;
  if (message.pageUrl) return message.pageUrl;
  if (message.referer) return message.referer;
  // Fall back to sniffed initiator for this media URL on the tab
  try {
    if (message.tabId != null && message.url) {
      const mediaMap = tabMedia.get(message.tabId);
      const item = mediaMap && mediaMap.get(message.url);
      if (item && item.initiator) return item.initiator;
    }
  } catch (e) {}
  return null;
}

// === Message Dispatcher ===
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'IS_URL_BLOCKED') {
    sendResponse({ blocked: fvdIsBlockedUrl(message.url) });
  }
  else if (message.type === 'PURGE_HISTORY') {
    purgeExpiredHistory().then(() => sendResponse({ status: 'ok' }));
    return true;
  }
  else if (message.type === 'SAVE_DOWNLOAD_FILE') {
    saveFileViaDownloads(message.blobUrl, message.filename)
      .then(() => sendResponse({ status: 'ok' }))
      .catch(err => sendResponse({ status: 'error', error: err && err.message ? err.message : 'Download failed' }));
    return true;
  }
  else if (message.type === 'GET_MEDIA') {
    const mediaMap = tabMedia.get(message.tabId);
    sendResponse({ media: mediaMap ? Array.from(mediaMap.values()) : [] });
  }
  else if (message.type === 'REFRESH_MEDIA') {
    const tabId = message.tabId;
    const mediaMap = tabMedia.get(tabId);
    if (mediaMap) {
      for (const url of [...mediaMap.keys()]) {
        if (isStreamingSegmentUrl(url) || isPreviewMediaUrl(url)) {
          mediaMap.delete(url);
        }
      }
      updateBadge(tabId);
      sendResponse({ media: Array.from(mediaMap.values()), status: 'ok' });
    } else {
      sendResponse({ media: [], status: 'ok' });
    }
  }
  // From content script: DOM-discovered media
  else if (message.type === 'FOUND_DOM_MEDIA') {
    const tabId = sender.tab ? sender.tab.id : null;
    if (tabId && Array.isArray(message.items)) {
      message.items.forEach(item => {
        const format = item.format || getFormat(item.url, '');
        addMediaItem(tabId, {
          url: item.url,
          filename: item.filename || getCleanFilename(item.url, '', ''),
          format,
          size: item.size || '',
          duration: item.duration || '',
          rawSize: 0,
          contentType: format === 'M3U8' ? 'application/vnd.apple.mpegurl' : 'video/mp4',
          fromPlaylist: !!item.fromPlaylist,
          quality: item.quality || '',
          discoveredAt: Date.now()
        });
      });
      tabBadgeCounts.set(tabId, message.items.length);
      updateBadge(tabId);
    }
    sendResponse({ status: 'ok' });
  }
  else if (message.type === 'COLLECT_MAIN_WORLD') {
    collectMainWorldMedia(message.tabId)
      .then((data) => sendResponse({ ok: true, data }))
      .catch(() => sendResponse({ ok: false, data: null }));
    return true;
  }
  else if (message.type === 'CLEAR_MEDIA') {
    if (message.tabId) {
      tabMedia.set(message.tabId, new Map());
      tabBadgeCounts.set(message.tabId, 0);
      updateBadge(message.tabId);
    }
    sendResponse({ status: 'ok' });
  }
  else if (message.type === 'SET_TAB_BADGE_COUNT') {
    if (message.tabId != null) {
      const count = Math.max(0, Number(message.count) || 0);
      tabBadgeCounts.set(message.tabId, count);
      updateBadge(message.tabId);
    }
    sendResponse({ status: 'ok' });
  }
  else if (message.type === 'START_HLS_DOWNLOAD') {
    if (fvdIsBlockedUrl(message.url)) {
      sendResponse({ status: 'blocked' });
      return;
    }
    startHlsDownload(message.downloadId, message.url, message.filename, resolvePageReferer(message))
      .then((result) => sendResponse(result || { status: 'started' }))
      .catch(() => sendResponse({ status: 'error' }));
    return true;
  }
  else if (message.type === 'START_DASH_DOWNLOAD') {
    if (fvdIsBlockedUrl(message.url)) {
      sendResponse({ status: 'blocked' });
      return;
    }
    startDashDownload(message.downloadId, message.url, message.filename, resolvePageReferer(message))
      .then((result) => sendResponse(result || { status: 'started' }))
      .catch(() => sendResponse({ status: 'error' }));
    return true;
  }
  else if (message.type === 'START_CHUNKED_DOWNLOAD') {
    if (fvdIsBlockedUrl(message.url)) {
      sendResponse({ status: 'blocked' });
      return;
    }
    startChunkedDownload(message.downloadId, message.url, message.filename, resolvePageReferer(message), message.threads || 1)
      .then((result) => sendResponse(result || { status: 'started' }))
      .catch(() => sendResponse({ status: 'error' }));
    return true;
  }
  else if (message.type === 'START_GENERIC_DOWNLOAD') {
    if (fvdIsBlockedUrl(message.url)) {
      sendResponse({ status: 'blocked' });
      return;
    }
    startGenericDownload(message.downloadId, message.url, message.filename, resolvePageReferer(message))
      .then((result) => sendResponse(result || { status: 'started' }))
      .catch(() => sendResponse({ status: 'error' }));
    return true;
  }
  else if (message.type === 'START_BLOB_DOWNLOAD') {
    if (fvdIsBlockedUrl(message.url)) {
      sendResponse({ status: 'blocked' });
      return;
    }
    startBlobDownload(message.downloadId, message.tabId, message.url, message.filename)
      .then((result) => sendResponse(result || { status: 'started' }))
      .catch(() => sendResponse({ status: 'error' }));
    return true;
  }
  // From popup: get all download states
  // From the engine tab: the file is ready, so bring that tab forward. Without a
  // download manager the save only happens through a click on a real link there.
  else if (message.type === 'ACTIVATE_ENGINE_TAB') {
    (async () => {
      const tabId = await findEngineTabId();
      if (tabId != null) {
        try {
          await chrome.tabs.update(tabId, { active: true });
        } catch (e) {}
      }
      sendResponse({ status: 'ok' });
    })();
    return true;
  }
  else if (message.type === 'GET_ALL_DOWNLOADS') {
    sendResponse({ downloads: Array.from(activeDownloads.values()) });
  }
  // From popup: log a direct (non-HLS) download to history
  else if (message.type === 'LOG_DIRECT_DOWNLOAD') {
    saveDownloadToHistory({
      filename: message.filename, url: message.url,
      size: message.size || 'Direct', duration: message.duration || ''
    });
    sendResponse({ status: 'ok' });
  }
  // From offscreen.js: progress update
  else if (message.type === 'OFFSCREEN_PROGRESS') {
    if (message.state && message.state.id) {
      // cancelled from offscreen -> remove locally too
      if (message.state.status === 'cancelled') {
        activeDownloads.delete(message.state.id);
        persistActiveDownloads();
        clearDownloadControlFlag(message.state.id);
        updateBadge();
        sendResponse({ status: 'ok' });
        return;
      }
      activeDownloads.set(message.state.id, message.state);
      persistActiveDownloads();

      // Auto-remove completed/error entries after 45s so the banner doesn't grow forever
      if (message.state.status === 'completed' || message.state.status === 'error') {
        clearDownloadControlFlag(message.state.id);
        const sid = message.state.id;
        if (!cleanupScheduled.has(sid)) {
          cleanupScheduled.add(sid);
          setTimeout(() => {
            cleanupScheduled.delete(sid);
            const cur = activeDownloads.get(sid);
            if (cur && (cur.status === 'completed' || cur.status === 'error')) {
              activeDownloads.delete(sid);
              persistActiveDownloads();
              updateBadge();
            }
          }, 45000);
        }
      }

      // Update badge with percentage
      if (message.state.status === 'downloading' && message.state.percent) {
        chrome.action.setBadgeText({ text: `${message.state.percent}%` });
        chrome.action.setBadgeBackgroundColor({ color: '#3b82f6' });
      } else if (message.state.status === 'paused') {
        chrome.action.setBadgeText({ text: '⏸' });
        chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
      } else if (message.state.status === 'merging') {
        chrome.action.setBadgeText({ text: '💾' });
      } else if (message.state.status === 'completed') {
        chrome.action.setBadgeText({ text: '✅' });
        maybeFlagReviewPrompt(message.state.id);
        setTimeout(() => updateBadge(), 5000);
      } else if (message.state.status === 'error') {
        chrome.action.setBadgeText({ text: '❌' });
      }
    }
    sendResponse({ status: 'ok' });
  }
  // From offscreen.js: download completed, save to history
  else if (message.type === 'OFFSCREEN_DOWNLOAD_COMPLETE') {
    if (FVD_DL_API) {
      saveDownloadToHistory({
        filename: message.filename, url: message.url,
        size: message.size || 'Stream', duration: message.duration || ''
      });
    } else {
      // With no download manager, downloads.onChanged never fires: this report is the
      // only completion signal there is. completeTrackedDownload() writes the history
      // entry and finishes the tracked download, so Free users still get the same
      // post-download page as on desktop.
      completeTrackedDownload(message.downloadId);
    }
    sendResponse({ status: 'ok' });
  }
  // From popup: pause / resume / cancel
  else if (message.type === 'PAUSE_DOWNLOAD') {
    (async () => {
      const dl = activeDownloads.get(message.downloadId);
      if (dl) {
        dl.status = 'paused';
        activeDownloads.set(message.downloadId, dl);
        persistActiveDownloads();
        await setDownloadControlFlag(message.downloadId, 'paused');
        chrome.action.setBadgeText({ text: '⏸' });
        chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
        await forwardToOffscreen('PAUSE_OFFSCREEN_DOWNLOAD', message.downloadId);
      }
      sendResponse({ status: 'paused' });
    })();
    return true;
  }
  else if (message.type === 'RESUME_DOWNLOAD') {
    (async () => {
      const dl = activeDownloads.get(message.downloadId);
      if (dl) {
        dl.status = 'downloading';
        activeDownloads.set(message.downloadId, dl);
        persistActiveDownloads();
        await setDownloadControlFlag(message.downloadId, 'downloading');
        chrome.action.setBadgeText({ text: `${dl.percent || 0}%` });
        chrome.action.setBadgeBackgroundColor({ color: '#3b82f6' });
        await forwardToOffscreen('RESUME_OFFSCREEN_DOWNLOAD', message.downloadId);
      }
      sendResponse({ status: 'resumed' });
    })();
    return true;
  }
  else if (message.type === 'CANCEL_DOWNLOAD') {
    (async () => {
      const dl = activeDownloads.get(message.downloadId);
      if (dl) {
        dl.status = 'cancelled';
        activeDownloads.set(message.downloadId, dl);
        persistActiveDownloads();
        await setDownloadControlFlag(message.downloadId, 'cancelled');
        updateBadge();
        await forwardToOffscreen('CANCEL_OFFSCREEN_DOWNLOAD', message.downloadId);
      }
      sendResponse({ status: 'cancelled' });
    })();
    return true;
  }
  else if (message.type === 'REMOVE_DOWNLOAD_ENTRY') {
    activeDownloads.delete(message.downloadId);
    persistActiveDownloads();
    updateBadge();
    sendResponse({ status: 'removed' });
  }
});

// === Right-click "Download this video" ===
const FVD_CTX_ID = 'fvd-download-media';

function fvdCreateContextMenu() {
  if (!chrome.contextMenus) return;
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: FVD_CTX_ID,
      title: chrome.i18n.getMessage('ctxDownloadVideo') || 'Download video with Flash Video Downloader',
      contexts: ['video', 'audio']
    }, () => void chrome.runtime.lastError);
  });
}
chrome.runtime.onInstalled.addListener(fvdCreateContextMenu);
if (chrome.runtime.onStartup) chrome.runtime.onStartup.addListener(fvdCreateContextMenu);

if (chrome.contextMenus) chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== FVD_CTX_ID || !tab) return;
  const tabId = tab.id;
  const pageUrl = info.frameUrl || info.pageUrl || tab.url || null;
  let url = info.srcUrl || '';
  // Players that use blob:/MediaSource or an empty src: fall back to what was sniffed on this tab
  if (!url || url.startsWith('blob:')) {
    const media = Array.from((tabMedia.get(tabId) || new Map()).values());
    const best = media.find(m => !isStreamingSegmentUrl(m.url) && !isPreviewMediaUrl(m.url));
    if (best) url = best.url;
  }
  let res = { ok: false };
  if (url && !fvdIsBlockedUrl(url) && !fvdIsBlockedUrl(pageUrl || '')) {
    const downloadId = btoa(unescape(encodeURIComponent(url))).replace(/[^a-zA-Z0-9]/g, '').slice(0, 24) + Date.now().toString(36);
    const filename = getCleanFilename(url, '', '');
    const format = getFormat(url, '');
    try {
      if (url.startsWith('blob:')) res = await startBlobDownload(downloadId, tabId, url, filename);
      else if (format === 'MPD') res = await startDashDownload(downloadId, url, filename, pageUrl);
      else if (format === 'M3U8') res = await startHlsDownload(downloadId, url, filename, pageUrl);
      else {
        const pro = await isProUser().catch(() => ({}));
        res = await startChunkedDownload(downloadId, url, filename, pageUrl, pro.isPro ? 8 : 1);
      }
    } catch (e) { res = { ok: false }; }
  }
  // Nothing usable, or terms/limit gate refused: show the popup, which explains and lets the user pick
  if (!res || res.ok === false || (res.status && res.status !== 'started')) {
    try { await chrome.action.openPopup(); } catch (e) {}
  }
});
